package com.example.phonenumbersapp

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.list_item.view.*

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var viewAdapter: RecyclerView.Adapter<*>
    private lateinit var viewManager: RecyclerView.LayoutManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        viewManager = LinearLayoutManager(this)
        viewAdapter = UserAdapter(usersList) {
            Toast
                .makeText(this@MainActivity,
                    "Clicked on user $it!",
                    Toast.LENGTH_SHORT)
                .show()
        }

        recyclerView = findViewById<RecyclerView>(R.id.my_recycler_view).apply {
            layoutManager = viewManager
            adapter = viewAdapter
        }


    }

    data class User(val firstName: String, val lastName: String)

    val usersList = (0..30).map {
        User("First name #$it", "Last name #$it")
    }

    class UserViewHolder(val root: View) : RecyclerView.ViewHolder(root) {
        val userFirstNameText = root.user_firstname
        val userLastNameText = root.user_lastname
    }

    class UserAdapter(
        val users: List<User>,
        val onClick: (User) -> Unit
    ) : RecyclerView.Adapter<UserViewHolder>() {
        override fun getItemCount(): Int = users.size
        override fun onBindViewHolder(holder: UserViewHolder, position: Int) {
            holder.userFirstNameText.text =
                users[position].firstName
            holder.userLastNameText.text =
                users[position].lastName
        }

        override fun onCreateViewHolder(
            parent: ViewGroup,
            viewType: Int
        ): UserViewHolder {
            val holder = UserViewHolder(
                LayoutInflater.from(parent.context).inflate(
                    R.layout.list_item,
                    parent,
                    false
                )
            )
            holder.root.setOnClickListener {
                onClick(users[holder.adapterPosition])
            }
            return holder
        }

    }


}
